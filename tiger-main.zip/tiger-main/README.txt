
Number of suppressed lines, suppressed chunks, average chunks size:
.                             :  604  87   6
    lib                       :   16  11   1
        misc                  :   16  11   1
            symbol.hxx        :    6   4   1
            test-symbol.cc    :    1   1   1
            unique.hxx        :    8   5   1
            variant.hxx       :    1   1   1
    src                       :  588  76   7
        ast                   :  332  47   7
            default-visitor.hxx:   20  11   1
            dumper-dot.cc~    :   37  28   1
            object-visitor.hxx:    9   5   1
            pretty-printer.cc :  236   2 118
            pretty-printer.hh :   30   1  30
        parse                 :  256  29   8
            parsetiger.yy     :  210   8  26
            scantiger.ll      :   26   3   8
            tasks.cc          :    1   1   1
            tiger-driver.cc   :    5   3   1
            tiger-factory.hxx :   14  14   1
