/**
 ** \file object/fwd.hh
 ** \brief Forward declarations of using types.
 */

#pragma once

#include <misc/map.hh>
#include <misc/symbol.hh>

namespace object
{} // namespace object
