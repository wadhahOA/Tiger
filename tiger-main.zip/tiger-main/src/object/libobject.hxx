#pragma once

/**
 ** \file object/libobject.hxx
 ** \brief Functions exported by the object module.
 */

#include <object/fwd.hh>

namespace object
{} // namespace object
