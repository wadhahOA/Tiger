/**
 ** \file object/libobject.cc
 ** \brief Define exported object functions.
 */

#include <object/libobject.hh>

namespace object
{} // namespace object
