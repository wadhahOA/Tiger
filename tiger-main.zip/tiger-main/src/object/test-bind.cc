/// Test the binding with object extensions.

#include <cstdlib>
#include <iostream>

#include <ast/chunk-list.hh>
#include <ast/exp.hh>
#include <ast/libast.hh>
#include <object/libobject.hh>
#include <parse/libparse.hh>

const char* program_name = "test-bind";

int main() {}
