/**
 ** \file ast/exp.hxx
 ** \brief Inline methods of ast::Exp.
 */

#pragma once

#include <ast/exp.hh>

namespace ast
{} // namespace ast
