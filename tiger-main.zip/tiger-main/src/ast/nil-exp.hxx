/**
 ** \file ast/nil-exp.hxx
 ** \brief Inline methods of ast::NilExp.
 */

#pragma once

#include <ast/nil-exp.hh>

namespace ast
{} // namespace ast
