/**
 ** \file ast/method-dec.hxx
 ** \brief Inline methods of ast::MethodDec.
 */

#pragma once

#include <ast/method-dec.hh>

namespace ast
{} // namespace ast
