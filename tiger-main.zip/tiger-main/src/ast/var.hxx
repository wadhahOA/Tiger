/**
 ** \file ast/var.hxx
 ** \brief Inline methods of ast::Var.
 */

#pragma once

#include <ast/var.hh>

namespace ast
{} // namespace ast
