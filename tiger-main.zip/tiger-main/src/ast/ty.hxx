/**
 ** \file ast/ty.hxx
 ** \brief Inline methods of ast::Ty.
 */

#pragma once

#include <ast/ty.hh>

namespace ast
{} // namespace ast
