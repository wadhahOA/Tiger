/**
 ** Testing the symbol tables.
 */

#include <ostream>

#include <misc/contract.hh>

int main() {}
