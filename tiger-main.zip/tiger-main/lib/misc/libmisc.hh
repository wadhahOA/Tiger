/**
 ** \file misc/libmisc.hh
 ** \brief A library of handy C++ tools.
 */

#pragma once

/// A set of handy C++ tools.
namespace misc
{} // namespace misc
